library(testthat)
library(FluxnetLSM)

test_check("FluxnetLSM")
